
/*
 *
 * 28May2020, Maiko (VE4KLM), no more hardcoded usage() functions !
 *  (users can customize the usage files to their own needs or wants)
 *
 * I just got tired of hardcoding them. The recompiles, restarts, wasting
 * my time and energy trying to nail down exact words, enough already ...
 *
 */

#include <stdio.h>

#define	MAXUSAGEFILEENTRYLEN 80

#ifdef	DONT_COMPILE
char *UsageFile = "/jnos/rte/usage";	/* temporary, put it in files.c later */
#endif

extern char *Usagedir;	/* defined in files.c */

extern void nos_log (int, char*, ...);

extern int tprintf (char *fmt, ...);

/*
 * 03Jun2020, Maiko, now has a return value, so the calling
 * routine can pick alternative usage method if it has one.
 */
int getusage (char *item)
{
	char buffer[MAXUSAGEFILEENTRYLEN+3];	/* watch for LF, CR, EOL, terminator ? */

	FILE *fp;

	sprintf (buffer, "%s/%s.txt", Usagedir, item);	/* should check length BEFORE I do this !!! */

	if (!(fp = fopen (buffer, "r")))
	{
		nos_log (-1, "can't open usage file [%s]", item);

		return 0;
	}

	while (fgets (buffer, MAXUSAGEFILEENTRYLEN, fp))
	{
		if (*buffer == '#' )
			continue;

		tprintf ("%s", buffer);
	}

 	fclose(fp);

	return 1;
}

